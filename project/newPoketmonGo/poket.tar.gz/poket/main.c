#include <stdio.h>
#include "map.h"
#include "parsing.h"


int main(){

	char buffer[500];
	char * result;

	initMap();
	cursorReset();
	FILE * fd = initFile();
	int x;
	int y;

	while(1){
		result = fgets(buffer,500,fd);
	
		if(result == NULL){
			break;
		}

		if(getGPSInfo(buffer,&x,&y)){
			printGPSXY(x,y);
		}
		sleep(1);
	}
	
	deinitFile();

	return 1;
}
